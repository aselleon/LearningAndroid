package com.example.lw5oaselnavigation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val btn_2 = findViewById<Button>(R.id.toThirdActivityBtn)
        val btn_3 = findViewById<Button>(R.id.toMainActivityBtn)

        btn_2.setOnClickListener {
            Intent(this,ThirdActivity::class.java).also {
                startActivity(it)
            }
        }

        btn_3.setOnClickListener {
            finish()
        }
    }
}