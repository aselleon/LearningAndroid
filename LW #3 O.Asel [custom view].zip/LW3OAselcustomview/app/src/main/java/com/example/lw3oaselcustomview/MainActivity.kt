package com.example.lw3oaselcustomview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity( ) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button)
        val addButton = findViewById<Button>(R.id.addButton)
        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val textView = findViewById<TextView>(R.id.textView)
        val closeButton = findViewById<Button>(R.id.closeButton)
        button.setOnClickListener {
            val custom = LayoutInflater.from(this).inflate(R.layout.custom,null);
            val myBuilder = AlertDialog.Builder(this)
                .setView(custom)
                .setTitle("Login Form")
            val myAlert = myBuilder.show()

            addButton.setOnClickListener {
                myAlert.dismiss()

            username.text.toString()
                password.text.toString()

                textView.setText("Name" + username,"password" + password)
            }

            closeButton.setOnClickListener {
                myAlert.dismiss()
            }

        }
    }
}