package com.example.lw6oaselrecyclerview.model

data class Affirmation(
    val stringResourceId: Int

    )