package com.example.lw6oaselrecyclerview.data

import com.example.lw6oaselrecyclerview.R
import com.example.lw6oaselrecyclerview.model.Affirmation

class Datasource {

    fun loadAffirmations(): List<Affirmation> {
        return listOf<Affirmation>(
            Affirmation(R.string.affirmation1),
            Affirmation(R.string.affirmation2),
            Affirmation(R.string.affirmation3),
            Affirmation(R.string.affirmation4),
            Affirmation(R.string.affirmation5)
        )
    }
}